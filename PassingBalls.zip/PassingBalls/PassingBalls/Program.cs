﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassingBalls
{
    class Program
    {
        static void Main(string[] args)
        {
            const int left = 1;
            List<Nodes> nodeList = new List<Nodes>();
            var nodeinit = new NodeInit();
            // Initiate all nodes node's names  are from 1 to  15 top 
            // to bottom
            // all gates set to right 
            nodeList =nodeinit.NodesSetup(1, 1);
           // Sort nodes 
           nodeList = nodeList.OrderBy(n => n.Name).ToList();
           // Set some Gate to left
            nodeList[1].Gate = left;
            nodeList[2].Gate = left;
            nodeList[9].Gate = left;
            nodeList[7].Gate = left;
            nodeList[10].Gate = left;
            nodeList[13].Gate = left;
            
            // set number of balls
            int BallsNum = 15;
            int temp = 0;
            char[] path = new char[16];
            // loop trough all balls, pass them to the nodes tree
            for (int i = 0; i < BallsNum; i++)
            {
                temp = nodeinit.NextNode(1, nodeList);
                temp = nodeinit.NextNode(temp, nodeList);
                temp = nodeinit.NextNode(temp, nodeList);
                if (nodeList[temp-1].Gate == 1)
                    nodeList[temp - 1].Gate = 2;
                else
                    nodeList[temp - 1].Gate = 1;
                // Store output in a array 
                path[i] = nodeinit.OutputGate(temp, nodeList[temp - 1].Gate);
               
            }

            // Print outputs to screen
            foreach (var item in path)
            {
                Console.Write(item+ " ");
               
            }
            Console.ReadLine();
            
        }
    }
}
