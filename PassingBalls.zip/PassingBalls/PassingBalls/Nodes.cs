﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassingBalls
{
    // Nodes class model
    public class Nodes
    {
        public int Name { get; set; }
        public int Level { get; set; }
        public int Parent { get; set; }
        public int Gate { get; set; }
        
    }
}
