﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassingBalls
{
    public class NodeInit
    {
        const int left = 1;
        const int right = 2;
        const int depth = 5;
        List<Nodes> nodeList = new List<Nodes>();
        // NodeSetup method  Recursively set all nodes , all instance of 
        // Nodes class stored in a list of nodes 
        // Default for nodes's gate set to right 
        public List<Nodes> NodesSetup(int parent, int level)
        {
                        int leftnod = parent + parent;
            int rightnod = leftnod + 1;
            Nodes nodeObj = new Nodes();
            // Initializing Nodes for four level depth 
            if (level < depth)
            { 
                NodesSetup( leftnod,  level + 1 );
                NodesSetup( rightnod,  level + 1);
                nodeObj.Gate = right;
                nodeObj.Level = level;
                nodeObj.Parent = parent/2;
                nodeObj.Name = parent;
                nodeList.Add(nodeObj);
            }

            return nodeList;

        }
        // NextNode Method find the next node based on left 
        //   or right gate is open
        public int NextNode(int node, List<Nodes> nodesListObj)
        {
            int index = node - 1;
            if (nodesListObj[index].Gate == left)
            {
                nodesListObj[index].Gate = right;
                return node + node+1;
            }
            else
            {
                nodesListObj[index].Gate = left;
                return node + node;
            }
        }
        // OutputGate map output gate to alphabetic character
        // Alphabetic character From A to P 
        public char OutputGate(int node, int gate)
        {
            char chr=' ';
            switch (node)
            {
                case 8:
                    if (gate == right)
                        chr = 'B';
                    else
                        chr = 'A';
                    break;
                case 9:
                    if (gate == right)
                        chr = 'D';
                    else
                        chr = 'C';
                    break;
                case 10:
                    if (gate == right)
                        chr = 'F';
                    else
                        chr = 'E';
                    break;
                case 11:
                    if (gate == right)
                        chr = 'H';
                    else
                        chr = 'G';
                    break;
                case 12:
                    if (gate == right)
                        chr = 'J';
                    else
                        chr = 'I';
                    break;
                case 13:
                    if (gate == right)
                        chr = 'L';
                    else
                        chr = 'K';
                    break;
                case 14:
                    if (gate == right)
                        chr = 'N';
                    else
                        chr = 'M';
                    break;
                case 15:
                    if (gate == right)
                        chr = 'P';
                    else
                        chr = 'O';
                    break;

            }
            return chr;
        }
        
    }
}
